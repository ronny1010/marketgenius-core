# MarketGenius — execution core

Milestone 0. The engine's uncertainty-handling core, proven against a deterministic
fault-injecting broker simulator. No dashboard, no live adapter, no order ever submitted.

```bash
pip install pytest
python3 -m pytest -q      # 59 passed
```

Read ARCHITECTURE.md first, then CURRENT_STATUS.md for exactly what is and isn't built.

This software makes no claim of profitability.
