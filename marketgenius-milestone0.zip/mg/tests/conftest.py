from __future__ import annotations

import uuid
from datetime import timedelta
from decimal import Decimal

import pytest

from packages.brokers.simulator import FakeBroker
from packages.domain.entities import (
    AccountSnapshot,
    OrderIntent,
    Quote,
    Signal,
    utc_now,
)
from packages.domain.enums import (
    AssetClass,
    Broker,
    Environment,
    IntentPurpose,
    OrderType,
    Side,
    TimeInForce,
)
from packages.order_coordinator.coordinator import OrderCoordinator
from packages.persistence.repository import InMemoryRepository
from packages.risk_engine.constitution import RiskConstitution
from packages.risk_engine.engine import RiskContext, RiskEngine
from packages.domain.enums import EngineState

SYMBOL = "BTC/USD"
PRICE = Decimal("60000.00")


@pytest.fixture
def broker() -> FakeBroker:
    return FakeBroker(environment=Environment.PAPER, prices={SYMBOL: PRICE})


@pytest.fixture
def repo() -> InMemoryRepository:
    return InMemoryRepository()


@pytest.fixture
def constitution() -> RiskConstitution:
    return RiskConstitution()


@pytest.fixture
def coordinator(broker, repo, constitution) -> OrderCoordinator:
    return OrderCoordinator(
        broker=broker,
        repository=repo,
        risk_engine=RiskEngine(constitution),
        environment=Environment.PAPER,
    )


def make_quote(age_seconds: int = 0, spread_bps: Decimal = Decimal("2")) -> Quote:
    half = PRICE * spread_bps / Decimal(20000)
    return Quote(
        symbol=SYMBOL, asset_class=AssetClass.CRYPTO, environment=Environment.PAPER,
        bid=(PRICE - half).quantize(Decimal("0.01")),
        ask=(PRICE + half).quantize(Decimal("0.01")),
        captured_at=utc_now() - timedelta(seconds=age_seconds),
        source="test", broker=Broker.SIMULATOR,
    )


def make_intent(
    qty: Decimal = Decimal("0.0002"),
    side: Side = Side.BUY,
    purpose: IntentPurpose = IntentPurpose.ENTRY,
    environment: Environment = Environment.PAPER,
    intent_id: str | None = None,
) -> OrderIntent:
    return OrderIntent(
        id=intent_id or str(uuid.uuid4()),
        environment=environment,
        broker=Broker.SIMULATOR,
        asset_class=AssetClass.CRYPTO,
        symbol=SYMBOL,
        side=side,
        qty=qty,
        order_type=OrderType.MARKET,
        time_in_force=TimeInForce.IOC,
        purpose=purpose,
        created_at=utc_now(),
        strategy_version="breakout@1.0.0",
    )


def make_signal(
    stop_distance: Decimal = Decimal("1000"),
    target_distance: Decimal = Decimal("4000"),
    direction: Side = Side.BUY,
) -> Signal:
    return Signal(
        symbol=SYMBOL, asset_class=AssetClass.CRYPTO, direction=direction,
        signal_at=utc_now(), completed_bar_at=utc_now(),
        entry_price=PRICE,
        invalidation_price=PRICE - stop_distance,
        target_price=PRICE + target_distance,
        strength=Decimal("0.8"), strategy_version="breakout@1.0.0",
    )


def make_context(
    broker: FakeBroker,
    quote: Quote | None = None,
    emergency_stop: bool = False,
    engine_state: EngineState = EngineState.RUNNING,
    **kw,
) -> RiskContext:
    return RiskContext(
        account=broker.get_account(),
        positions=list(broker.list_positions()),
        quote=quote or make_quote(),
        engine_state=engine_state,
        emergency_stop=emergency_stop,
        **kw,
    )
