"""Risk engine: every limit in the constitution is enforced, and emergency stop
blocks entries while permitting risk reduction."""
from __future__ import annotations

from decimal import Decimal

from packages.domain.entities import Position, utc_now
from packages.domain.enums import (
    AssetClass,
    Broker,
    EngineState,
    Environment,
    IntentPurpose,
    Side,
)
from packages.risk_engine.constitution import RiskConstitution
from packages.risk_engine.engine import RiskContext, RiskEngine
from tests.conftest import PRICE, SYMBOL, make_context, make_intent, make_quote, make_signal


def engine(**overrides) -> RiskEngine:
    return RiskEngine(RiskConstitution(**overrides))


def _position(symbol: str = "ETH/USD", notional: str = "20.00") -> Position:
    return Position(
        environment=Environment.PAPER, broker=Broker.SIMULATOR,
        asset_class=AssetClass.CRYPTO, symbol=symbol,
        qty=Decimal("1"), avg_entry_price=Decimal(notional), opened_at=utc_now())


def test_approves_a_compliant_entry(broker):
    decision = engine().evaluate(make_intent(), make_context(broker), make_signal())
    assert decision.approved is True, decision.reasons


def test_decision_records_constitution_checksum(broker):
    c = RiskConstitution()
    decision = RiskEngine(c).evaluate(make_intent(), make_context(broker), make_signal())
    assert decision.constitution_checksum == c.checksum
    assert len(c.checksum) == 16


def test_emergency_stop_blocks_entry(broker):
    decision = engine().evaluate(
        make_intent(purpose=IntentPurpose.ENTRY),
        make_context(broker, emergency_stop=True), make_signal())
    assert decision.approved is False
    assert "EMERGENCY_STOP_ACTIVE" in decision.reasons


def test_emergency_stop_permits_risk_reducing_exit(broker):
    decision = engine().evaluate(
        make_intent(side=Side.SELL, purpose=IntentPurpose.RISK_REDUCING),
        make_context(broker, emergency_stop=True), make_signal())
    assert decision.approved is True, decision.reasons


def test_position_size_cap_enforced(broker):
    decision = engine().evaluate(
        make_intent(qty=Decimal("0.001")),   # ~$60 at 60k, cap is $20
        make_context(broker), make_signal())
    assert any(r.startswith("POSITION_TOO_LARGE") for r in decision.reasons)


def test_total_exposure_cap_enforced(broker):
    ctx = RiskContext(
        account=broker.get_account(),
        positions=[_position(notional="35.00")],
        quote=make_quote(), engine_state=EngineState.RUNNING, emergency_stop=False)
    decision = engine().evaluate(make_intent(qty=Decimal("0.0002")), ctx, make_signal())
    assert any(r.startswith("EXPOSURE_LIMIT") for r in decision.reasons)


def test_max_open_positions_enforced(broker):
    ctx = RiskContext(
        account=broker.get_account(),
        positions=[_position("ETH/USD", "5.00"), _position("SOL/USD", "5.00")],
        quote=make_quote(), engine_state=EngineState.RUNNING, emergency_stop=False)
    decision = engine().evaluate(make_intent(), ctx, make_signal())
    assert any(r.startswith("MAX_OPEN_POSITIONS") for r in decision.reasons)


def test_averaging_down_prohibited(broker):
    ctx = RiskContext(
        account=broker.get_account(),
        positions=[_position(SYMBOL, "5.00")],
        quote=make_quote(), engine_state=EngineState.RUNNING, emergency_stop=False)
    decision = engine().evaluate(make_intent(), ctx, make_signal())
    assert "AVERAGING_DOWN_PROHIBITED" in decision.reasons


def test_shorting_prohibited_on_entry(broker):
    decision = engine().evaluate(
        make_intent(side=Side.SELL), make_context(broker),
        make_signal(direction=Side.SELL))
    assert "SHORTING_PROHIBITED" in decision.reasons


def test_stale_quote_blocks_entry(broker):
    decision = engine().evaluate(
        make_intent(), make_context(broker, quote=make_quote(age_seconds=60)), make_signal())
    assert any(r.startswith("QUOTE_STALE") for r in decision.reasons)


def test_wide_spread_blocks_entry(broker):
    decision = engine().evaluate(
        make_intent(),
        make_context(broker, quote=make_quote(spread_bps=Decimal("400"))), make_signal())
    assert any(r.startswith("SPREAD_TOO_WIDE") for r in decision.reasons)


def test_planned_loss_cap_enforced(broker):
    """Stop far enough away that the $1 planned-loss cap binds."""
    decision = engine().evaluate(
        make_intent(qty=Decimal("0.0002")),
        make_context(broker),
        make_signal(stop_distance=Decimal("30000"), target_distance=Decimal("90000")))
    assert any(r.startswith("PLANNED_LOSS_TOO_LARGE") for r in decision.reasons)


def test_reward_to_risk_measured_after_costs(broker):
    decision = engine().evaluate(
        make_intent(),
        make_context(broker),
        make_signal(stop_distance=Decimal("1000"), target_distance=Decimal("1000")))
    assert any(r.startswith("REWARD_TO_RISK_TOO_LOW") for r in decision.reasons)


def test_daily_loss_limit_enforced(broker):
    decision = engine().evaluate(
        make_intent(), make_context(broker, realized_pnl_today=Decimal("-5.00")),
        make_signal())
    assert any(r.startswith("DAILY_LOSS_LIMIT") for r in decision.reasons)


def test_drawdown_limit_enforced(broker):
    decision = engine().evaluate(
        make_intent(), make_context(broker, rolling_drawdown=Decimal("15.00")), make_signal())
    assert any(r.startswith("DRAWDOWN_LIMIT") for r in decision.reasons)


def test_daily_entry_count_enforced(broker):
    decision = engine().evaluate(
        make_intent(), make_context(broker, entries_today=3), make_signal())
    assert any(r.startswith("DAILY_ENTRY_LIMIT") for r in decision.reasons)


def test_engine_must_be_running_to_enter(broker):
    decision = engine().evaluate(
        make_intent(), make_context(broker, engine_state=EngineState.PAUSED_RISK),
        make_signal())
    assert any(r.startswith("ENGINE_NOT_RUNNING") for r in decision.reasons)


def test_entry_without_signal_is_refused(broker):
    decision = engine().evaluate(make_intent(), make_context(broker), signal=None)
    assert "NO_SIGNAL_ATTACHED" in decision.reasons


def test_evaluation_is_deterministic(broker):
    ctx, intent, signal = make_context(broker), make_intent(), make_signal()
    a = engine().evaluate(intent, ctx, signal)
    b = engine().evaluate(intent, ctx, signal)
    assert a.approved == b.approved and a.reasons == b.reasons
