"""Cross-cutting invariants: market data hygiene, ledger precision, and the
architectural boundary that keeps strategies away from brokers."""
from __future__ import annotations

import pathlib
from datetime import timedelta
from decimal import Decimal

import pytest

from packages.brokers.simulator import FakeBroker
from packages.domain.entities import Bar, utc_now
from packages.domain.enums import AssetClass, Environment
from packages.domain.money import D, money, notional, quantity
from packages.market_data.bars import FormingBarError, assert_all_complete, prepare
from packages.strategies import breakout

REPO_ROOT = pathlib.Path(__file__).resolve().parents[2]


def _bar(i: int, close: str, complete: bool = True, high: str | None = None) -> Bar:
    closed = utc_now().replace(microsecond=0) - timedelta(hours=100 - i)
    px = Decimal(close)
    return Bar(symbol="BTC/USD", timeframe="1h", opened_at=closed - timedelta(hours=1),
               closed_at=closed, open=px, high=Decimal(high or close), low=px - Decimal("10"),
               close=px, volume=Decimal("1"), source="test", is_complete=complete)


# ---------------- market data hygiene ----------------

def test_forming_bars_are_excluded_from_series():
    raw = [_bar(i, "100") for i in range(5)] + [_bar(5, "999", complete=False)]
    series = prepare("BTC/USD", "1h", raw)
    assert len(series) == 5
    assert all(b.is_complete for b in series.bars)


def test_forming_bar_reaching_a_strategy_raises():
    with pytest.raises(FormingBarError):
        assert_all_complete([_bar(0, "100", complete=False)])


def test_duplicate_bars_are_removed():
    b = _bar(1, "100")
    series = prepare("BTC/USD", "1h", [b, b, b])
    assert len(series) == 1


def test_gaps_are_reported_never_manufactured():
    raw = [_bar(1, "100"), _bar(4, "103")]   # hours 2 and 3 missing
    series = prepare("BTC/USD", "1h", raw)
    assert len(series) == 2, "missing bars must not be synthesised"
    assert len(series.gaps) == 2


def test_bars_are_ordered_ascending():
    series = prepare("BTC/USD", "1h", [_bar(3, "103"), _bar(1, "101"), _bar(2, "102")])
    assert [b.close for b in series.bars] == [Decimal("101"), Decimal("102"), Decimal("103")]


# ---------------- strategy behaviour ----------------

def test_strategy_never_reads_the_forming_bar():
    raw = [_bar(i, "100", high="100") for i in range(30)]
    raw.append(_bar(30, "500", complete=False, high="500"))   # would break out
    series = prepare("BTC/USD", "1h", raw)
    assert breakout.generate(series, AssetClass.CRYPTO) is None


def test_no_trade_is_a_valid_result():
    series = prepare("BTC/USD", "1h", [_bar(i, "100", high="100") for i in range(30)])
    assert breakout.generate(series, AssetClass.CRYPTO) is None


def test_breakout_produces_signal_with_required_fields():
    raw = [_bar(i, "100", high="101") for i in range(30)]
    raw.append(_bar(30, "130", high="130"))
    series = prepare("BTC/USD", "1h", raw)

    signal = breakout.generate(series, AssetClass.CRYPTO)

    assert signal is not None
    assert signal.strategy_version == breakout.VERSION
    assert signal.invalidation_price < signal.entry_price < signal.target_price
    assert signal.completed_bar_at == series.last.closed_at
    assert Decimal("0") <= signal.strength <= Decimal("1")


def test_strategy_module_cannot_reach_a_broker():
    """Architectural invariant: no strategy imports the broker layer."""
    for path in (REPO_ROOT / "packages" / "strategies").glob("*.py"):
        imports = [ln.strip() for ln in path.read_text().splitlines()
                   if ln.strip().startswith(("import ", "from "))]
        for line in imports:
            assert "packages.brokers" not in line, f"{path.name} imports the broker layer"
            assert not line.startswith(("import requests", "import httpx")), path.name


# ---------------- ledger precision ----------------

def test_floats_are_rejected_in_ledger_arithmetic():
    with pytest.raises(TypeError):
        D(0.1 + 0.2)


def test_money_reconciles_to_the_smallest_unit():
    total = sum((money("0.01") for _ in range(100)), Decimal("0"))
    assert total == Decimal("1.00")


def test_quantity_rounds_down_never_up():
    assert quantity("0.1234567899") == Decimal("0.123456789")


def test_fee_in_quote_currency_reconciles():
    broker = FakeBroker(environment=Environment.PAPER,
                        prices={"BTC/USD": Decimal("60000.00")}, fee_in_asset=False)
    starting_cash = broker.cash
    from tests.conftest import make_intent
    intent = make_intent(qty=Decimal("0.0002"))
    broker.submit_order(intent)

    fill = broker.list_fills(intent.client_order_id)[0]
    expected = money(fill.gross_notional + fill.fee.amount)
    assert fill.fee.currency == "USD"
    assert starting_cash - broker.cash == expected


def test_fee_charged_in_purchased_asset_reconciles():
    broker = FakeBroker(environment=Environment.PAPER,
                        prices={"BTC/USD": Decimal("60000.00")}, fee_in_asset=True)
    from tests.conftest import make_intent
    intent = make_intent(qty=Decimal("0.0002"))
    broker.submit_order(intent)

    fill = broker.list_fills(intent.client_order_id)[0]
    position = broker.list_positions()[0]
    assert fill.fee.charged_in_asset is True
    assert position.qty == quantity(fill.qty - fill.fee.amount)


def test_notional_uses_decimal_throughout():
    assert notional(Decimal("0.0002"), Decimal("60000.00")) == Decimal("12.00")


# ---------------- test-suite safety ----------------

def test_no_test_contacts_a_live_endpoint():
    """No network client and no broker hostname may appear in the test tree."""
    banned = ("api.alpaca.markets", "paper-api.alpaca.markets", "api.coinbase.com",
              "api-fxtrade.oanda.com", "clob.polymarket.com", "import requests", "import httpx")
    for path in (REPO_ROOT / "tests").rglob("*.py"):
        if path.resolve() == pathlib.Path(__file__).resolve():
            continue  # this file names the banned tokens in order to ban them
        source = path.read_text()
        for token in banned:
            assert token not in source, f"{path.name} references {token}"
