"""Order coordinator invariants under hostile broker conditions."""
from __future__ import annotations

from decimal import Decimal

import pytest

from packages.brokers.simulator import LookupBehaviour, SubmitBehaviour
from packages.domain.enums import (
    Environment,
    IntentPurpose,
    ReservationState,
    Side,
)
from packages.order_coordinator.coordinator import EnvironmentMismatch
from packages.persistence.repository import WriteFailure
from tests.conftest import make_context, make_intent, make_quote, make_signal


def test_happy_path_submits_exactly_one_order(coordinator, broker):
    result = coordinator.place(make_intent(), make_context(broker), make_signal())

    assert result.accepted is True
    assert result.state is ReservationState.SUBMITTED
    assert len(broker.submit_calls) == 1
    assert len(broker.list_fills(result.reservation.client_order_id)) == 1


def test_duplicate_invocation_never_produces_two_broker_orders(coordinator, broker):
    intent = make_intent(intent_id="fixed-intent-1")

    first = coordinator.place(intent, make_context(broker), make_signal())
    second = coordinator.place(intent, make_context(broker), make_signal())

    assert first.accepted is True
    assert second.reason == "ALREADY_SUBMITTED"
    assert len(broker.submit_calls) == 1, "a single intent reached the venue twice"


@pytest.mark.parametrize(
    "behaviour",
    [
        SubmitBehaviour.TIMEOUT_BEFORE_ACCEPT,
        SubmitBehaviour.TIMEOUT_AFTER_ACCEPT,
        SubmitBehaviour.HTTP_500,
        SubmitBehaviour.HTTP_401,
        SubmitBehaviour.HTTP_429,
        SubmitBehaviour.MALFORMED,
    ],
)
def test_ambiguous_submit_never_resubmits(coordinator, broker, behaviour):
    """Every ambiguous failure mode ends in RECOVERY_REQUIRED with exactly one
    submission attempt. This is the invariant that prevents doubled orders."""
    broker.submit_script = [behaviour]
    intent = make_intent(intent_id="fixed-intent-2")

    result = coordinator.place(intent, make_context(broker), make_signal())

    assert result.accepted is False
    assert result.state is ReservationState.RECOVERY_REQUIRED
    assert len(broker.submit_calls) == 1

    # A second call must not "retry" it either.
    retry = coordinator.place(intent, make_context(broker), make_signal())
    assert retry.accepted is False
    assert len(broker.submit_calls) == 1


def test_explicit_rejection_is_not_treated_as_uncertain(coordinator, broker):
    broker.submit_script = [SubmitBehaviour.REJECT]

    result = coordinator.place(make_intent(), make_context(broker), make_signal())

    assert result.state is ReservationState.REJECTED
    assert "BROKER_REJECTED" in result.reason


def test_timeout_after_acceptance_leaves_order_at_venue(coordinator, broker):
    """The dangerous case: we time out, but the venue holds the order."""
    broker.submit_script = [SubmitBehaviour.TIMEOUT_AFTER_ACCEPT]
    intent = make_intent(intent_id="fixed-intent-3")

    result = coordinator.place(intent, make_context(broker), make_signal())

    assert result.state is ReservationState.RECOVERY_REQUIRED
    lookup = broker.find_order_by_client_id(intent.client_order_id)
    assert lookup.status.value == "FOUND", "venue really does hold the order"


def test_finalization_write_failure_escalates_not_retries(coordinator, broker, repo):
    """Broker accepted, our database write failed. Never resubmit."""
    repo.fail_next_saves = 1
    repo.fail_on_states = (ReservationState.SUBMITTED,)

    result = coordinator.place(make_intent(), make_context(broker), make_signal())

    assert result.accepted is False
    assert result.state is ReservationState.RECOVERY_REQUIRED
    assert len(broker.submit_calls) == 1
    incidents = repo.list_incidents(Environment.PAPER)
    assert incidents and incidents[0].kind == "FINALIZE_WRITE_FAILED"


def test_pre_submit_lookup_unknown_blocks_submission(coordinator, broker):
    """If we cannot confirm the venue's state before submitting, we do not
    submit at all."""
    broker.lookup_script = [LookupBehaviour.TIMEOUT]

    result = coordinator.place(make_intent(), make_context(broker), make_signal())

    assert result.reason == "PRE_SUBMIT_LOOKUP_UNKNOWN"
    assert broker.submit_calls == []


def test_pre_submit_lookup_found_adopts_instead_of_duplicating(coordinator, broker):
    """A previous process already placed this exact client_order_id."""
    intent = make_intent(intent_id="fixed-intent-4")
    broker.submit_order(intent)                      # simulate the prior process
    submissions_before = len(broker.submit_calls)

    result = coordinator.place(intent, make_context(broker), make_signal())

    assert result.accepted is True
    assert result.reason == "ADOPTED_EXISTING_BROKER_ORDER"
    assert len(broker.submit_calls) == submissions_before


def test_client_order_id_is_stable_across_attempts():
    a = make_intent(intent_id="same-id")
    b = make_intent(intent_id="same-id")
    assert a.client_order_id == b.client_order_id
    assert a.client_order_id.startswith("mg-paper-")


def test_paper_intent_cannot_route_to_live_coordinator(broker, repo, constitution):
    from packages.order_coordinator.coordinator import OrderCoordinator
    from packages.risk_engine.engine import RiskEngine

    live_coordinator = OrderCoordinator(
        broker=broker, repository=repo,
        risk_engine=RiskEngine(constitution), environment=Environment.LIVE)

    with pytest.raises(EnvironmentMismatch):
        live_coordinator.place(make_intent(environment=Environment.PAPER),
                               make_context(broker), make_signal())


def test_live_and_paper_ledgers_never_mix(coordinator, broker, repo):
    coordinator.place(make_intent(), make_context(broker), make_signal())

    assert len(repo.list_fills(Environment.PAPER)) == 1
    assert len(repo.list_fills(Environment.LIVE)) == 0
    assert len(repo.list_reservations(Environment.LIVE, list(ReservationState))) == 0


def test_partial_fill_is_recorded_accurately(coordinator, broker):
    broker.submit_script = [SubmitBehaviour.PARTIAL_FILL]

    result = coordinator.place(make_intent(qty=Decimal("0.0002")),
                               make_context(broker), make_signal())

    fills = broker.list_fills(result.reservation.client_order_id)
    assert result.accepted is True
    assert sum(f.qty for f in fills) == Decimal("0.0001")


def test_delayed_fill_settles_without_new_submission(coordinator, broker):
    broker.submit_script = [SubmitBehaviour.DELAYED_FILL]
    result = coordinator.place(make_intent(), make_context(broker), make_signal())
    coid = result.reservation.client_order_id

    assert broker.list_fills(coid) == []
    broker.settle_delayed(coid)

    assert len(broker.list_fills(coid)) == 1
    assert len(broker.submit_calls) == 1
