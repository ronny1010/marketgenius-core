"""Adversarial sweep: every submit x lookup fault combination, run through
coordinator + recovery, asserting the two invariants that matter most:
  - at most ONE broker order per intent
  - local state never claims SUBMITTED without broker truth
"""
import itertools
from decimal import Decimal
from packages.brokers.simulator import FakeBroker, SubmitBehaviour, LookupBehaviour
from packages.domain.enums import Environment, ReservationState, OrderLookupStatus
from packages.order_coordinator.coordinator import OrderCoordinator
from packages.order_coordinator.recovery import RecoveryWorker
from packages.persistence.repository import InMemoryRepository
from packages.risk_engine.constitution import RiskConstitution
from packages.risk_engine.engine import RiskEngine
from tests.conftest import make_intent, make_signal, make_context, SYMBOL, PRICE

submits = [v for k,v in vars(SubmitBehaviour).items() if not k.startswith("_")]
lookups = [v for k,v in vars(LookupBehaviour).items() if not k.startswith("_")]


def test_no_fault_combination_produces_a_duplicate_or_phantom_order():
  violations, runs = [], 0
  for sb, lb, fail_write in itertools.product(submits, lookups, [False, True]):
      runs += 1
      broker = FakeBroker(environment=Environment.PAPER, prices={SYMBOL: PRICE})
      repo = InMemoryRepository()
      coord = OrderCoordinator(broker, repo, RiskEngine(RiskConstitution()), Environment.PAPER)
      intent = make_intent(intent_id=f"fuzz-{sb}-{lb}-{fail_write}")

      broker.submit_script = [sb]
      if fail_write:
          repo.fail_next_saves = 1
          repo.fail_on_states = (ReservationState.SUBMITTED,)

      try: coord.place(intent, make_context(broker), make_signal())
      except Exception as e: violations.append(f"{sb}/{lb}: place raised {e!r}")

      # three recovery passes under the scripted lookup fault, then clean passes
      broker.lookup_script = [lb, lb, lb]
      for _ in range(3):
          try: RecoveryWorker(broker, repo, Environment.PAPER).run()
          except Exception as e: violations.append(f"{sb}/{lb}: recovery raised {e!r}")
      for _ in range(2):
          RecoveryWorker(broker, repo, Environment.PAPER).run()

      # retry the same intent after everything settles
      try: coord.place(intent, make_context(broker), make_signal())
      except Exception as e: violations.append(f"{sb}/{lb}: retry raised {e!r}")

      coid = intent.client_order_id
      submitted = broker.submit_calls.count(coid)
      if submitted > 1:
          violations.append(f"{sb}/{lb}/fw={fail_write}: DUPLICATE ORDER x{submitted}")

      res = repo.get_reservation(coid, Environment.PAPER)
      if res and res.state is ReservationState.SUBMITTED:
          # local claims submitted -> broker must actually hold it
          broker.lookup_script = []
          if broker.find_order_by_client_id(coid).status is not OrderLookupStatus.FOUND:
              violations.append(f"{sb}/{lb}/fw={fail_write}: PHANTOM SUBMITTED state")
      if repo.list_fills(Environment.LIVE):
          violations.append(f"{sb}/{lb}: LIVE ledger contaminated")

  assert not violations, violations
  assert runs == 100
