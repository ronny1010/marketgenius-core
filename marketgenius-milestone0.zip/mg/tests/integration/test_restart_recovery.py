"""Restart and uncertain-order recovery.

Each test simulates a process death at a different point in the submission
sequence, then boots the recovery worker against broker truth.
"""
from __future__ import annotations

from packages.brokers.simulator import LookupBehaviour, SubmitBehaviour
from packages.domain.enums import Environment, ReservationState
from packages.order_coordinator.recovery import RecoveryWorker
from tests.conftest import make_context, make_intent, make_signal


def _worker(broker, repo) -> RecoveryWorker:
    return RecoveryWorker(broker=broker, repository=repo, environment=Environment.PAPER)


def test_recovery_adopts_order_the_broker_actually_holds(coordinator, broker, repo):
    """Timeout after acceptance: recovery must find and adopt the real order."""
    broker.submit_script = [SubmitBehaviour.TIMEOUT_AFTER_ACCEPT]
    intent = make_intent(intent_id="recover-1")
    coordinator.place(intent, make_context(broker), make_signal())

    report = _worker(broker, repo).run()

    reservation = repo.get_reservation(intent.client_order_id, Environment.PAPER)
    assert report.adopted == 1
    assert reservation.state is ReservationState.SUBMITTED
    assert reservation.broker_order_id is not None
    assert len(broker.submit_calls) == 1, "recovery must never resubmit"


def test_recovery_abandons_order_the_broker_never_received(coordinator, broker, repo):
    """Timeout before acceptance: the venue confirms absence, so the intent is
    closed out. Recovery still does not resubmit -- a new decision must."""
    broker.submit_script = [SubmitBehaviour.TIMEOUT_BEFORE_ACCEPT]
    intent = make_intent(intent_id="recover-2")
    coordinator.place(intent, make_context(broker), make_signal())

    report = _worker(broker, repo).run()

    reservation = repo.get_reservation(intent.client_order_id, Environment.PAPER)
    assert report.abandoned == 1
    assert reservation.state is ReservationState.ABANDONED
    assert len(broker.submit_calls) == 1


def test_recovery_leaves_unknown_unresolved_rather_than_guessing(coordinator, broker, repo):
    """If the venue is still unreachable, staying stuck is the correct outcome."""
    broker.submit_script = [SubmitBehaviour.TIMEOUT_AFTER_ACCEPT]
    intent = make_intent(intent_id="recover-3")
    coordinator.place(intent, make_context(broker), make_signal())

    broker.lookup_script = [LookupBehaviour.HTTP_500]
    report = _worker(broker, repo).run()

    reservation = repo.get_reservation(intent.client_order_id, Environment.PAPER)
    assert report.still_unknown == 1
    assert reservation.state is ReservationState.RECOVERY_REQUIRED
    assert len(broker.submit_calls) == 1


def test_recovery_is_idempotent_across_repeated_runs(coordinator, broker, repo):
    broker.submit_script = [SubmitBehaviour.TIMEOUT_AFTER_ACCEPT]
    intent = make_intent(intent_id="recover-4")
    coordinator.place(intent, make_context(broker), make_signal())

    first = _worker(broker, repo).run()
    second = _worker(broker, repo).run()

    assert first.adopted == 1
    assert second.adopted == 0, "already-resolved reservations are not reprocessed"
    assert len(broker.submit_calls) == 1


def test_recovery_then_retry_still_cannot_duplicate(coordinator, broker, repo):
    """After recovery adopts the order, a naive retry of the same intent must
    still be refused."""
    broker.submit_script = [SubmitBehaviour.TIMEOUT_AFTER_ACCEPT]
    intent = make_intent(intent_id="recover-5")
    coordinator.place(intent, make_context(broker), make_signal())
    _worker(broker, repo).run()

    retry = coordinator.place(intent, make_context(broker), make_signal())

    assert retry.reason == "ALREADY_SUBMITTED"
    assert len(broker.submit_calls) == 1
