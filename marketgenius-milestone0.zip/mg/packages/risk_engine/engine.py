"""Deterministic risk evaluation.

Pure function of (constitution, intent, signal, live account/position/market
state). No randomness, no network, no LLM. The same inputs always produce the
same decision and the same ordered reason list.

Runs immediately before broker submission, on freshly fetched state -- never on
cached state from earlier in the cycle.
"""
from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from typing import Optional, Sequence

from packages.domain.entities import (
    AccountSnapshot,
    OrderIntent,
    Position,
    Quote,
    RiskDecision,
    Signal,
    utc_now,
)
from packages.domain.enums import EngineState, IntentPurpose, Side
from packages.domain.money import ZERO, money, notional
from .constitution import RiskConstitution


@dataclass(frozen=True)
class RiskContext:
    """Everything the engine is allowed to look at."""

    account: AccountSnapshot
    positions: Sequence[Position]
    quote: Quote
    engine_state: EngineState
    emergency_stop: bool
    realized_pnl_today: Decimal = ZERO
    rolling_drawdown: Decimal = ZERO
    entries_today: int = 0
    open_intent_count: int = 0

    @property
    def total_exposure(self) -> Decimal:
        return money(sum((p.notional for p in self.positions), ZERO))

    def position_for(self, symbol: str) -> Optional[Position]:
        return next((p for p in self.positions if p.symbol == symbol), None)


class RiskEngine:
    def __init__(self, constitution: RiskConstitution):
        self.constitution = constitution

    def evaluate(
        self,
        intent: OrderIntent,
        ctx: RiskContext,
        signal: Optional[Signal] = None,
    ) -> RiskDecision:
        c = self.constitution
        reasons: list[str] = []
        is_entry = intent.purpose is IntentPurpose.ENTRY

        # --- Gates that apply to entries only. Risk-reducing work stays
        # --- permitted so we are never trapped in a position we cannot exit.
        if is_entry:
            if ctx.emergency_stop:
                reasons.append("EMERGENCY_STOP_ACTIVE")
            if ctx.engine_state is not EngineState.RUNNING:
                reasons.append(f"ENGINE_NOT_RUNNING:{ctx.engine_state.value}")

        # --- Structural prohibitions ---
        if c.long_only and intent.side is Side.SELL and is_entry:
            reasons.append("SHORTING_PROHIBITED")
        if not c.allow_shorting and is_entry and intent.side is Side.SELL:
            if "SHORTING_PROHIBITED" not in reasons:
                reasons.append("SHORTING_PROHIBITED")

        # --- Market quality ---
        age = ctx.quote.age_seconds()
        if age > c.max_quote_age_seconds:
            reasons.append(f"QUOTE_STALE:{age}s>{c.max_quote_age_seconds}s")
        max_spread = c.max_spread_for(intent.asset_class)
        if ctx.quote.spread_bps > max_spread:
            reasons.append(f"SPREAD_TOO_WIDE:{ctx.quote.spread_bps:.1f}bps>{max_spread}bps")

        if is_entry:
            reasons.extend(self._entry_checks(intent, ctx, signal))

        approved = not reasons
        return RiskDecision(
            approved=approved,
            reasons=tuple(reasons),
            constitution_checksum=c.checksum,
            decided_at=utc_now(),
            approved_qty=intent.qty if approved else ZERO,
            approved_notional=notional(intent.qty, ctx.quote.ask) if approved else ZERO,
        )

    def _entry_checks(
        self, intent: OrderIntent, ctx: RiskContext, signal: Optional[Signal]
    ) -> list[str]:
        c = self.constitution
        reasons: list[str] = []
        intended_notional = notional(intent.qty, ctx.quote.ask)

        if intended_notional > c.max_position_notional:
            reasons.append(
                f"POSITION_TOO_LARGE:${intended_notional}>${c.max_position_notional}")

        if ctx.total_exposure + intended_notional > c.max_total_exposure:
            reasons.append(
                f"EXPOSURE_LIMIT:${ctx.total_exposure + intended_notional}"
                f">${c.max_total_exposure}")

        if intended_notional > c.authorized_capital:
            reasons.append("EXCEEDS_AUTHORIZED_CAPITAL")

        if intended_notional > ctx.account.buying_power:
            reasons.append("INSUFFICIENT_BUYING_POWER")

        existing = ctx.position_for(intent.symbol)
        if existing is not None and not c.allow_averaging_down:
            reasons.append("AVERAGING_DOWN_PROHIBITED")

        open_slots = len(ctx.positions) + ctx.open_intent_count
        if existing is None and open_slots >= c.max_open_positions:
            reasons.append(f"MAX_OPEN_POSITIONS:{open_slots}>={c.max_open_positions}")

        if ctx.entries_today >= c.max_entries_per_day:
            reasons.append(f"DAILY_ENTRY_LIMIT:{ctx.entries_today}>={c.max_entries_per_day}")

        if ctx.realized_pnl_today <= -c.max_realized_daily_loss:
            reasons.append(f"DAILY_LOSS_LIMIT:${ctx.realized_pnl_today}")

        if ctx.rolling_drawdown >= c.max_rolling_drawdown:
            reasons.append(f"DRAWDOWN_LIMIT:${ctx.rolling_drawdown}")

        if signal is not None:
            reasons.extend(self._signal_checks(intent, ctx, signal, intended_notional))
        else:
            reasons.append("NO_SIGNAL_ATTACHED")

        return reasons

    def _signal_checks(
        self,
        intent: OrderIntent,
        ctx: RiskContext,
        signal: Signal,
        intended_notional: Decimal,
    ) -> list[str]:
        c = self.constitution
        reasons: list[str] = []

        # Planned loss = distance to invalidation * size, plus costs.
        per_unit_risk = abs(ctx.quote.ask - signal.invalidation_price)
        planned_loss = money(per_unit_risk * intent.qty)
        est_fees = money(intended_notional * c.assumed_fee_rate * Decimal(2))
        est_slippage = money(intended_notional * c.assumed_slippage_bps / Decimal(10000))
        planned_loss_with_costs = money(planned_loss + est_fees + est_slippage)

        if planned_loss_with_costs > c.max_planned_loss_per_trade:
            reasons.append(
                f"PLANNED_LOSS_TOO_LARGE:${planned_loss_with_costs}"
                f">${c.max_planned_loss_per_trade}")

        # Reward-to-risk measured net of estimated costs, not gross.
        gross_reward = money(abs(signal.target_price - ctx.quote.ask) * intent.qty)
        net_reward = money(gross_reward - est_fees - est_slippage)
        if planned_loss <= ZERO:
            reasons.append("INVALID_STOP_DISTANCE")
        else:
            rr = net_reward / planned_loss
            if rr < c.min_reward_to_risk_after_costs:
                reasons.append(
                    f"REWARD_TO_RISK_TOO_LOW:{rr:.2f}<{c.min_reward_to_risk_after_costs}")

        if signal.direction is not intent.side:
            reasons.append("SIGNAL_DIRECTION_MISMATCH")

        return reasons
