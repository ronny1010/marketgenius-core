"""The RiskConstitution: one immutable, checksummed set of limits.

There is exactly one of these in force at a time. It is loaded from the
database, hashed, and every RiskDecision records the checksum that produced it,
so any decision can be re-derived years later.

Nothing in the system may raise a limit at runtime. Changing limits means
writing a new constitution row, which is an audited configuration change.
"""
from __future__ import annotations

import hashlib
import json
from dataclasses import asdict, dataclass, field
from decimal import Decimal

from packages.domain.enums import AssetClass


@dataclass(frozen=True)
class RiskConstitution:
    version: str = "v1"

    # Capital limits (USD)
    authorized_capital: Decimal = Decimal("100.00")
    max_position_notional: Decimal = Decimal("20.00")
    max_total_exposure: Decimal = Decimal("40.00")
    max_open_positions: int = 2
    max_planned_loss_per_trade: Decimal = Decimal("1.00")
    max_realized_daily_loss: Decimal = Decimal("5.00")
    max_rolling_drawdown: Decimal = Decimal("15.00")
    max_entries_per_day: int = 3

    # Structural prohibitions
    long_only: bool = True
    allow_leverage: bool = False
    allow_margin: bool = False
    allow_shorting: bool = False
    allow_options: bool = False
    allow_derivatives: bool = False
    allow_averaging_down: bool = False
    allow_martingale: bool = False

    # Execution quality gates
    min_reward_to_risk_after_costs: Decimal = Decimal("1.5")
    max_quote_age_seconds: Decimal = Decimal("10")
    max_spread_bps: dict = field(default_factory=lambda: {
        AssetClass.US_EQUITY.value: Decimal("25"),
        AssetClass.CRYPTO.value: Decimal("50"),
        AssetClass.FOREX.value: Decimal("15"),
        AssetClass.PREDICTION.value: Decimal("200"),
    })

    # Cost assumptions used when testing R:R after costs
    assumed_fee_rate: Decimal = Decimal("0.001")
    assumed_slippage_bps: Decimal = Decimal("5")

    @property
    def checksum(self) -> str:
        payload = json.dumps(asdict(self), sort_keys=True, default=str)
        return hashlib.sha256(payload.encode()).hexdigest()[:16]

    def max_spread_for(self, asset_class: AssetClass) -> Decimal:
        return self.max_spread_bps[asset_class.value]


DEFAULT_CONSTITUTION = RiskConstitution()
