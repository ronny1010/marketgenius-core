"""Donchian channel breakout. Versioned and deterministic.

This module imports nothing from packages.brokers. That is an architectural
invariant, asserted by tests/unit/test_invariants.py: a strategy has no way
to reach a venue. It returns a Signal or None, and "no trade" is a valid,
frequently correct result.
"""
from __future__ import annotations

from decimal import Decimal
from typing import Optional

from packages.domain.entities import Signal, utc_now
from packages.domain.enums import AssetClass, Side
from packages.market_data.bars import BarSeries, assert_all_complete

VERSION = "breakout@1.0.0"


def generate(
    series: BarSeries,
    asset_class: AssetClass,
    lookback: int = 20,
    stop_atr_multiple: Decimal = Decimal("1.0"),
    target_multiple: Decimal = Decimal("2.5"),
) -> Optional[Signal]:
    assert_all_complete(series.bars)

    if len(series) < lookback + 1:
        return _no_signal(series, asset_class, ("INSUFFICIENT_HISTORY",))

    window = series.bars[-(lookback + 1):-1]     # excludes the bar being tested
    trigger = series.last                        # newest COMPLETED bar
    channel_high = max(b.high for b in window)
    channel_low = min(b.low for b in window)

    if trigger.close <= channel_high:
        return _no_signal(series, asset_class, ("NO_BREAKOUT",))

    ranges = [b.high - b.low for b in window]
    atr = sum(ranges, Decimal(0)) / Decimal(len(ranges))
    if atr <= 0:
        return _no_signal(series, asset_class, ("ZERO_VOLATILITY",))

    entry = trigger.close
    stop = entry - (atr * stop_atr_multiple)
    target = entry + (atr * stop_atr_multiple * target_multiple)

    breakout_size = (trigger.close - channel_high) / atr
    strength = min(Decimal("1.0"), breakout_size).quantize(Decimal("0.01"))

    return Signal(
        symbol=series.symbol,
        asset_class=asset_class,
        direction=Side.BUY,
        signal_at=utc_now(),
        completed_bar_at=trigger.closed_at,
        entry_price=entry,
        invalidation_price=stop,
        target_price=target,
        strength=strength,                # rule alignment, not P(profit)
        strategy_version=VERSION,
        supporting={
            "channel_high": str(channel_high),
            "channel_low": str(channel_low),
            "atr": str(atr),
            "lookback": lookback,
        },
    )


def _no_signal(series: BarSeries, asset_class: AssetClass, reasons: tuple) -> None:
    """No trade is a valid result. Reasons are persisted by the caller."""
    return None
