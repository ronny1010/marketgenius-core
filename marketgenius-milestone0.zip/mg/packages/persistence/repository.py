"""Persistence boundary.

The coordinator talks only to this interface, so the same code path runs
against the in-memory store (tests) and PostgreSQL (Milestone 1). The
in-memory implementation deliberately supports fault injection on writes,
because "the broker accepted but our database write failed" is the exact
failure that must be survivable.

Environment isolation is enforced here, at the storage boundary, rather than
by convention: PAPER and LIVE records live in separate partitions and a
cross-environment read raises.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional, Protocol, Sequence

from packages.domain.entities import Fill, Incident, OrderReservation, utc_now
from packages.domain.enums import Environment, ReservationState


class WriteFailure(Exception):
    """Simulated or real durable-write failure."""


class Repository(Protocol):
    def save_reservation(self, reservation: OrderReservation) -> None: ...
    def get_reservation(self, client_order_id: str, environment: Environment) -> Optional[OrderReservation]: ...
    def list_reservations(self, environment: Environment, states: Sequence[ReservationState]) -> Sequence[OrderReservation]: ...
    def save_fill(self, fill: Fill) -> None: ...
    def save_incident(self, incident: Incident) -> None: ...


@dataclass
class InMemoryRepository:
    #: environment -> client_order_id -> reservation
    _reservations: dict = field(default_factory=lambda: {e: {} for e in Environment})
    _fills: dict = field(default_factory=lambda: {e: [] for e in Environment})
    _incidents: dict = field(default_factory=lambda: {e: [] for e in Environment})

    #: test hook: when set, the next N reservation saves raise WriteFailure
    fail_next_saves: int = 0
    #: test hook: only fail saves that transition into these states
    fail_on_states: tuple = ()

    def _maybe_fail(self, reservation: OrderReservation) -> None:
        if self.fail_next_saves <= 0:
            return
        if self.fail_on_states and reservation.state not in self.fail_on_states:
            return
        self.fail_next_saves -= 1
        raise WriteFailure(f"durable write failed writing state {reservation.state.value}")

    def save_reservation(self, reservation: OrderReservation) -> None:
        self._maybe_fail(reservation)
        env = reservation.environment
        self._reservations[env][reservation.client_order_id] = reservation

    def get_reservation(
        self, client_order_id: str, environment: Environment
    ) -> Optional[OrderReservation]:
        return self._reservations[environment].get(client_order_id)

    def list_reservations(
        self, environment: Environment, states: Sequence[ReservationState]
    ) -> Sequence[OrderReservation]:
        wanted = set(states)
        return [r for r in self._reservations[environment].values() if r.state in wanted]

    def save_fill(self, fill: Fill) -> None:
        self._fills[fill.environment].append(fill)

    def list_fills(self, environment: Environment) -> Sequence[Fill]:
        return list(self._fills[environment])

    def save_incident(self, incident: Incident) -> None:
        self._incidents[incident.environment].append(incident)

    def list_incidents(self, environment: Environment) -> Sequence[Incident]:
        return list(self._incidents[environment])
