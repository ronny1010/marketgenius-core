"""Canonical entities.

Deliberately stdlib dataclasses rather than Pydantic/SQLAlchemy models: this
package is the shared vocabulary and must import cleanly in any context,
including tests that run without a database. Milestone 1 adds SQLAlchemy
mappings in packages/persistence that project onto these same shapes.

Every record carries: identifier, environment, broker, asset class, canonical
symbol, timestamps, provenance, and strategy version where applicable.
"""
from __future__ import annotations

import hashlib
from dataclasses import dataclass, field, replace
from datetime import datetime, timezone
from decimal import Decimal
from typing import Optional

from .enums import (
    AssetClass,
    Broker,
    BrokerOrderStatus,
    Environment,
    IntentPurpose,
    OrderType,
    ReservationState,
    Side,
    TimeInForce,
)
from .money import ZERO, money, quantity


def utc_now() -> datetime:
    """All internal timestamps are timezone-aware UTC."""
    return datetime.now(timezone.utc)


@dataclass(frozen=True)
class Instrument:
    symbol: str
    asset_class: AssetClass
    broker: Broker
    environment: Environment
    tradable: bool = True
    min_qty: Decimal = Decimal("0.000000001")
    price_increment: Decimal = Decimal("0.01")


@dataclass(frozen=True)
class Quote:
    symbol: str
    asset_class: AssetClass
    environment: Environment
    bid: Decimal
    ask: Decimal
    captured_at: datetime
    source: str  # provenance: which provider produced this
    broker: Broker = Broker.ALPACA

    @property
    def mid(self) -> Decimal:
        return money((self.bid + self.ask) / Decimal(2))

    @property
    def spread(self) -> Decimal:
        return money(self.ask - self.bid)

    @property
    def spread_bps(self) -> Decimal:
        if self.mid == ZERO:
            return Decimal("99999")
        return (self.spread / self.mid) * Decimal(10000)

    def age_seconds(self, now: Optional[datetime] = None) -> Decimal:
        now = now or utc_now()
        return Decimal(str((now - self.captured_at).total_seconds()))


@dataclass(frozen=True)
class Bar:
    """A price bar. `is_complete` is set by the market-data layer only when the
    bar's window has closed. Strategies may never read an incomplete bar."""

    symbol: str
    timeframe: str  # "15m" | "1h" | "1d"
    opened_at: datetime
    closed_at: datetime
    open: Decimal
    high: Decimal
    low: Decimal
    close: Decimal
    volume: Decimal
    source: str
    is_complete: bool


@dataclass(frozen=True)
class Signal:
    """Produced by strategies. Carries no authority to trade."""

    symbol: str
    asset_class: AssetClass
    direction: Side
    signal_at: datetime
    completed_bar_at: datetime
    entry_price: Decimal
    invalidation_price: Decimal  # stop
    target_price: Decimal
    strength: Decimal  # rule-alignment score, NOT a probability of profit
    strategy_version: str
    supporting: dict = field(default_factory=dict)
    rejection_reasons: tuple[str, ...] = ()

    @property
    def reward_to_risk(self) -> Decimal:
        risk = abs(self.entry_price - self.invalidation_price)
        if risk == ZERO:
            return ZERO
        return abs(self.target_price - self.entry_price) / risk


@dataclass(frozen=True)
class RiskDecision:
    approved: bool
    reasons: tuple[str, ...]
    constitution_checksum: str
    decided_at: datetime
    approved_qty: Decimal = ZERO
    approved_notional: Decimal = ZERO

    @property
    def primary_reason(self) -> str:
        return self.reasons[0] if self.reasons else ("APPROVED" if self.approved else "REJECTED")


@dataclass(frozen=True)
class OrderIntent:
    """The unit of work handed to the OrderCoordinator.

    `client_order_id` is derived deterministically from the intent id and
    environment so that a retry, a restart, or a recovery pass all look up the
    same identifier at the broker.
    """

    id: str
    environment: Environment
    broker: Broker
    asset_class: AssetClass
    symbol: str
    side: Side
    qty: Decimal
    order_type: OrderType
    time_in_force: TimeInForce
    purpose: IntentPurpose
    created_at: datetime
    strategy_version: Optional[str] = None
    limit_price: Optional[Decimal] = None
    source: str = "opportunity_engine"

    @property
    def client_order_id(self) -> str:
        raw = f"{self.environment.value}:{self.broker.value}:{self.id}"
        digest = hashlib.sha256(raw.encode()).hexdigest()[:24]
        return f"mg-{self.environment.value.lower()}-{digest}"


@dataclass
class OrderReservation:
    """Durable local record of an intent's lifecycle. Written BEFORE any broker
    call so that a crash mid-submission is always recoverable."""

    intent: OrderIntent
    state: ReservationState
    created_at: datetime
    updated_at: datetime
    broker_order_id: Optional[str] = None
    last_error: Optional[str] = None
    attempts: int = 0
    incident_id: Optional[str] = None

    @property
    def client_order_id(self) -> str:
        return self.intent.client_order_id

    @property
    def environment(self) -> Environment:
        return self.intent.environment

    def transition(self, state: ReservationState, **kw) -> None:
        self.state = state
        self.updated_at = utc_now()
        for k, v in kw.items():
            setattr(self, k, v)


@dataclass(frozen=True)
class BrokerOrder:
    broker_order_id: str
    client_order_id: str
    environment: Environment
    broker: Broker
    symbol: str
    side: Side
    qty: Decimal
    status: BrokerOrderStatus
    filled_qty: Decimal
    avg_fill_price: Optional[Decimal]
    submitted_at: datetime
    source: str = "broker"


@dataclass(frozen=True)
class Fee:
    """A fee may be charged in the quote currency (cash) or in the purchased
    asset itself (common on crypto venues). Both must reconcile."""

    amount: Decimal
    currency: str  # "USD" or the asset symbol
    charged_in_asset: bool


@dataclass(frozen=True)
class Fill:
    id: str
    broker_order_id: str
    client_order_id: str
    environment: Environment
    broker: Broker
    symbol: str
    side: Side
    qty: Decimal
    price: Decimal
    filled_at: datetime
    fee: Fee
    source: str = "broker"

    @property
    def gross_notional(self) -> Decimal:
        return money(self.qty * self.price)


@dataclass
class Position:
    environment: Environment
    broker: Broker
    asset_class: AssetClass
    symbol: str
    qty: Decimal
    avg_entry_price: Decimal
    opened_at: datetime
    source: str = "broker"

    @property
    def notional(self) -> Decimal:
        return money(self.qty * self.avg_entry_price)


@dataclass(frozen=True)
class Incident:
    id: str
    environment: Environment
    kind: str
    detail: str
    created_at: datetime
    client_order_id: Optional[str] = None
    resolved: bool = False


@dataclass(frozen=True)
class AccountSnapshot:
    environment: Environment
    broker: Broker
    cash: Decimal
    equity: Decimal
    buying_power: Decimal
    captured_at: datetime
    source: str = "broker"


__all__ = [n for n in dir() if not n.startswith("_")]
