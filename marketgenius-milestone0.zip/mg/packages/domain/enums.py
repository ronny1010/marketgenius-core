"""Canonical enumerations. No behaviour here beyond identity."""
from __future__ import annotations

from enum import Enum


class Environment(str, Enum):
    PAPER = "PAPER"
    LIVE = "LIVE"


class Broker(str, Enum):
    ALPACA = "ALPACA"
    COINBASE = "COINBASE"
    OANDA = "OANDA"
    POLYMARKET = "POLYMARKET"
    SIMULATOR = "SIMULATOR"


class AssetClass(str, Enum):
    US_EQUITY = "US_EQUITY"
    CRYPTO = "CRYPTO"
    FOREX = "FOREX"
    PREDICTION = "PREDICTION"


class Side(str, Enum):
    BUY = "BUY"
    SELL = "SELL"


class OrderType(str, Enum):
    MARKET = "MARKET"
    LIMIT = "LIMIT"


class TimeInForce(str, Enum):
    DAY = "DAY"
    GTC = "GTC"
    IOC = "IOC"


class EngineState(str, Enum):
    STOPPED = "STOPPED"
    RUNNING = "RUNNING"
    PAUSED_RISK = "PAUSED_RISK"
    PAUSED_INFRASTRUCTURE = "PAUSED_INFRASTRUCTURE"
    RECOVERY_REQUIRED = "RECOVERY_REQUIRED"


class ReservationState(str, Enum):
    """State machine for a single order intent's lifecycle.

    CREATED -> RESERVED -> SUBMITTING -> (SUBMITTED | ABANDONED | RECOVERY_REQUIRED)
    SUBMITTED -> FINALIZED
    RECOVERY_REQUIRED is terminal only for the coordinator; the recovery
    worker resolves it against broker truth.
    """

    CREATED = "CREATED"
    RESERVED = "RESERVED"
    SUBMITTING = "SUBMITTING"
    SUBMITTED = "SUBMITTED"
    FINALIZED = "FINALIZED"
    RECOVERY_REQUIRED = "RECOVERY_REQUIRED"
    REJECTED = "REJECTED"
    ABANDONED = "ABANDONED"


#: States from which the coordinator must never submit a fresh broker order
#: without first confirming broker absence.
UNCERTAIN_STATES = frozenset(
    {
        ReservationState.SUBMITTING,
        ReservationState.RECOVERY_REQUIRED,
    }
)


class OrderLookupStatus(str, Enum):
    """The only three answers a broker lookup may return.

    Anything ambiguous -- timeout, 5xx, auth failure, rate limit, malformed
    payload, network error -- is UNKNOWN. UNKNOWN must never trigger an
    automatic resubmission.
    """

    FOUND = "FOUND"
    CONFIRMED_NOT_FOUND = "CONFIRMED_NOT_FOUND"
    UNKNOWN = "UNKNOWN"


class BrokerOrderStatus(str, Enum):
    ACCEPTED = "ACCEPTED"
    PARTIALLY_FILLED = "PARTIALLY_FILLED"
    FILLED = "FILLED"
    CANCELED = "CANCELED"
    REJECTED = "REJECTED"


class IntentPurpose(str, Enum):
    """Whether an intent opens/increases risk or reduces it.

    Emergency stop blocks ENTRY. It never blocks RISK_REDUCING work.
    """

    ENTRY = "ENTRY"
    RISK_REDUCING = "RISK_REDUCING"
