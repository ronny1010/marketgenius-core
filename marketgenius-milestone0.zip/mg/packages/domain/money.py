"""Decimal-only money and quantity arithmetic.

Binary floats are never used for ledger values. Every value that reaches the
ledger is a Decimal quantised to a declared precision.
"""
from __future__ import annotations

from decimal import Decimal, ROUND_DOWN, ROUND_HALF_EVEN, getcontext

getcontext().prec = 28

#: Smallest supported unit for cash amounts (USD cents).
CASH_EXPONENT = Decimal("0.01")

#: Quantity precision by asset class; crypto needs sub-unit precision.
QTY_EXPONENT_DEFAULT = Decimal("0.000000001")


def D(value: str | int | Decimal) -> Decimal:
    """Construct a Decimal. Floats are rejected on purpose."""
    if isinstance(value, float):
        raise TypeError(
            "float is not permitted in ledger arithmetic; pass str or Decimal"
        )
    return Decimal(value)


def money(value: str | int | Decimal) -> Decimal:
    """Quantise to the smallest supported cash unit, banker's rounding."""
    return D(value).quantize(CASH_EXPONENT, rounding=ROUND_HALF_EVEN)


def quantity(value: str | int | Decimal, exponent: Decimal = QTY_EXPONENT_DEFAULT) -> Decimal:
    """Quantise a quantity, always rounding DOWN so we never buy more than sized."""
    return D(value).quantize(exponent, rounding=ROUND_DOWN)


def notional(qty: Decimal, price: Decimal) -> Decimal:
    """Cash value of qty at price."""
    return money(D(qty) * D(price))


ZERO = Decimal("0")
