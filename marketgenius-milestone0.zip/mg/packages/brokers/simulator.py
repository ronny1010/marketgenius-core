"""Deterministic broker simulator.

Used by every automated test. It never performs network I/O, so tests
structurally cannot contact a live endpoint. Faults are scripted, not random,
so failures reproduce exactly.

It also enforces venue-side idempotency: submitting a second order with a
client_order_id already seen raises BrokerRejected, mirroring how Alpaca,
Coinbase and OANDA behave. That means the "one intent, one order" invariant is
tested against a hostile venue rather than a cooperative one.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import timedelta
from decimal import Decimal
from typing import Optional, Sequence

from packages.domain.entities import (
    AccountSnapshot,
    Bar,
    BrokerOrder,
    Fee,
    Fill,
    Instrument,
    OrderIntent,
    Position,
    Quote,
    utc_now,
)
from packages.domain.enums import (
    AssetClass,
    Broker,
    BrokerOrderStatus,
    Environment,
    OrderLookupStatus,
    Side,
)
from packages.domain.money import money, quantity
from .contract import (
    BrokerAuthError,
    BrokerMalformedResponse,
    BrokerRateLimited,
    BrokerRejected,
    BrokerTimeout,
    BrokerUnavailable,
    OrderLookup,
)


class SubmitBehaviour:
    OK = "OK"
    REJECT = "REJECT"
    PARTIAL_FILL = "PARTIAL_FILL"
    DELAYED_FILL = "DELAYED_FILL"
    TIMEOUT_BEFORE_ACCEPT = "TIMEOUT_BEFORE_ACCEPT"
    TIMEOUT_AFTER_ACCEPT = "TIMEOUT_AFTER_ACCEPT"
    HTTP_401 = "HTTP_401"
    HTTP_429 = "HTTP_429"
    HTTP_500 = "HTTP_500"
    MALFORMED = "MALFORMED"


class LookupBehaviour:
    NORMAL = "NORMAL"
    TIMEOUT = "TIMEOUT"
    HTTP_500 = "HTTP_500"
    MALFORMED = "MALFORMED"
    HTTP_404 = "HTTP_404"  # a genuine, durable "not found"


@dataclass
class FakeBroker:
    environment: Environment = Environment.PAPER
    name: str = "simulator"
    broker: Broker = Broker.SIMULATOR

    cash: Decimal = Decimal("100.00")
    equity: Decimal = Decimal("100.00")
    prices: dict = field(default_factory=lambda: {"BTC/USD": Decimal("60000.00")})
    fee_rate: Decimal = Decimal("0.001")
    fee_in_asset: bool = False

    submit_script: list = field(default_factory=list)
    lookup_script: list = field(default_factory=list)

    _orders: dict = field(default_factory=dict)          # client_order_id -> BrokerOrder
    _fills: dict = field(default_factory=dict)           # client_order_id -> list[Fill]
    _positions: dict = field(default_factory=dict)       # symbol -> Position
    submit_calls: list = field(default_factory=list)     # every client_order_id ever submitted
    lookup_calls: list = field(default_factory=list)
    _seq: int = 0

    # ---------------- scripting ----------------

    def _next_submit(self) -> str:
        return self.submit_script.pop(0) if self.submit_script else SubmitBehaviour.OK

    def _next_lookup(self) -> str:
        return self.lookup_script.pop(0) if self.lookup_script else LookupBehaviour.NORMAL

    def _next_id(self, prefix: str) -> str:
        self._seq += 1
        return f"{prefix}-{self._seq:04d}"

    # ---------------- account & data ----------------

    def get_account(self) -> AccountSnapshot:
        return AccountSnapshot(
            environment=self.environment,
            broker=self.broker,
            cash=money(self.cash),
            equity=money(self.equity),
            buying_power=money(self.cash),
            captured_at=utc_now(),
        )

    def list_instruments(self) -> Sequence[Instrument]:
        return [
            Instrument(symbol=s, asset_class=AssetClass.CRYPTO, broker=self.broker,
                       environment=self.environment)
            for s in self.prices
        ]

    def is_market_open(self, symbol: str) -> bool:
        return True

    def get_quote(self, symbol: str) -> Quote:
        px = self.prices[symbol]
        half = money(px * Decimal("0.0001"))
        return Quote(symbol=symbol, asset_class=AssetClass.CRYPTO,
                     environment=self.environment, bid=money(px - half),
                     ask=money(px + half), captured_at=utc_now(),
                     source="simulator", broker=self.broker)

    def get_bars(self, symbol: str, timeframe: str, limit: int) -> Sequence[Bar]:
        now = utc_now().replace(second=0, microsecond=0)
        px = self.prices[symbol]
        out = []
        for i in range(limit, 0, -1):
            closed = now - timedelta(hours=i)
            out.append(Bar(symbol=symbol, timeframe=timeframe,
                           opened_at=closed - timedelta(hours=1), closed_at=closed,
                           open=px, high=px, low=px, close=px,
                           volume=Decimal("1"), source="simulator", is_complete=True))
        return out

    def list_positions(self) -> Sequence[Position]:
        return list(self._positions.values())

    def list_open_orders(self) -> Sequence[BrokerOrder]:
        return [o for o in self._orders.values()
                if o.status in (BrokerOrderStatus.ACCEPTED, BrokerOrderStatus.PARTIALLY_FILLED)]

    # ---------------- order lifecycle ----------------

    def find_order_by_client_id(self, client_order_id: str) -> OrderLookup:
        self.lookup_calls.append(client_order_id)
        behaviour = self._next_lookup()

        if behaviour == LookupBehaviour.TIMEOUT:
            raise BrokerTimeout("lookup timed out")
        if behaviour == LookupBehaviour.HTTP_500:
            raise BrokerUnavailable("500 from venue")
        if behaviour == LookupBehaviour.MALFORMED:
            raise BrokerMalformedResponse("unparseable lookup payload")
        if behaviour == LookupBehaviour.HTTP_404:
            return OrderLookup(status=OrderLookupStatus.CONFIRMED_NOT_FOUND)

        order = self._orders.get(client_order_id)
        if order is None:
            return OrderLookup(status=OrderLookupStatus.CONFIRMED_NOT_FOUND)
        return OrderLookup(status=OrderLookupStatus.FOUND, order=order)

    def submit_order(self, intent: OrderIntent) -> BrokerOrder:
        coid = intent.client_order_id
        self.submit_calls.append(coid)

        # Venue-side idempotency: a duplicate client order id is refused.
        if coid in self._orders:
            raise BrokerRejected(f"duplicate client_order_id {coid}")

        behaviour = self._next_submit()

        if behaviour == SubmitBehaviour.TIMEOUT_BEFORE_ACCEPT:
            raise BrokerTimeout("timed out before acceptance")
        if behaviour == SubmitBehaviour.HTTP_401:
            raise BrokerAuthError("401 unauthorized")
        if behaviour == SubmitBehaviour.HTTP_429:
            raise BrokerRateLimited("429 rate limited")
        if behaviour == SubmitBehaviour.HTTP_500:
            raise BrokerUnavailable("500 internal error")
        if behaviour == SubmitBehaviour.MALFORMED:
            raise BrokerMalformedResponse("unparseable submit payload")
        if behaviour == SubmitBehaviour.REJECT:
            raise BrokerRejected("insufficient buying power")

        order = self._accept(intent, behaviour)

        if behaviour == SubmitBehaviour.TIMEOUT_AFTER_ACCEPT:
            # The venue holds the order; the caller learns nothing. This is the
            # single most dangerous case in the whole system.
            raise BrokerTimeout("timed out after acceptance")

        return order

    def _accept(self, intent: OrderIntent, behaviour: str) -> BrokerOrder:
        coid = intent.client_order_id
        bid = self._next_id("sim-order")
        px = self.prices[intent.symbol]

        if behaviour == SubmitBehaviour.DELAYED_FILL:
            filled, status = Decimal("0"), BrokerOrderStatus.ACCEPTED
        elif behaviour == SubmitBehaviour.PARTIAL_FILL:
            filled, status = quantity(intent.qty / 2), BrokerOrderStatus.PARTIALLY_FILLED
        else:
            filled, status = intent.qty, BrokerOrderStatus.FILLED

        order = BrokerOrder(
            broker_order_id=bid, client_order_id=coid, environment=self.environment,
            broker=self.broker, symbol=intent.symbol, side=intent.side, qty=intent.qty,
            status=status, filled_qty=filled,
            avg_fill_price=px if filled > 0 else None, submitted_at=utc_now(),
        )
        self._orders[coid] = order
        if filled > 0:
            self._record_fill(order, filled, px)
        return order

    def _record_fill(self, order: BrokerOrder, qty: Decimal, price: Decimal) -> None:
        gross = money(qty * price)
        if self.fee_in_asset:
            fee = Fee(amount=quantity(qty * self.fee_rate), currency=order.symbol.split("/")[0],
                      charged_in_asset=True)
            received = quantity(qty - fee.amount)
            cash_delta = gross
        else:
            fee = Fee(amount=money(gross * self.fee_rate), currency="USD", charged_in_asset=False)
            received = qty
            cash_delta = money(gross + fee.amount)

        fill = Fill(id=self._next_id("sim-fill"), broker_order_id=order.broker_order_id,
                    client_order_id=order.client_order_id, environment=self.environment,
                    broker=self.broker, symbol=order.symbol, side=order.side, qty=qty,
                    price=price, filled_at=utc_now(), fee=fee)
        self._fills.setdefault(order.client_order_id, []).append(fill)

        sign = Decimal(1) if order.side is Side.BUY else Decimal(-1)
        self.cash = money(self.cash - sign * cash_delta)
        existing = self._positions.get(order.symbol)
        new_qty = quantity((existing.qty if existing else Decimal(0)) + sign * received)
        if new_qty == 0:
            self._positions.pop(order.symbol, None)
        else:
            self._positions[order.symbol] = Position(
                environment=self.environment, broker=self.broker,
                asset_class=AssetClass.CRYPTO, symbol=order.symbol, qty=new_qty,
                avg_entry_price=price, opened_at=utc_now())

    def settle_delayed(self, client_order_id: str) -> None:
        """Test hook: complete a previously ACCEPTED-but-unfilled order."""
        order = self._orders[client_order_id]
        px = self.prices[order.symbol]
        remaining = order.qty - order.filled_qty
        self._orders[client_order_id] = BrokerOrder(
            broker_order_id=order.broker_order_id, client_order_id=client_order_id,
            environment=order.environment, broker=order.broker, symbol=order.symbol,
            side=order.side, qty=order.qty, status=BrokerOrderStatus.FILLED,
            filled_qty=order.qty, avg_fill_price=px, submitted_at=order.submitted_at)
        if remaining > 0:
            self._record_fill(self._orders[client_order_id], remaining, px)

    def cancel_order(self, broker_order_id: str) -> None:
        for coid, o in list(self._orders.items()):
            if o.broker_order_id == broker_order_id:
                self._orders[coid] = BrokerOrder(
                    broker_order_id=o.broker_order_id, client_order_id=coid,
                    environment=o.environment, broker=o.broker, symbol=o.symbol,
                    side=o.side, qty=o.qty, status=BrokerOrderStatus.CANCELED,
                    filled_qty=o.filled_qty, avg_fill_price=o.avg_fill_price,
                    submitted_at=o.submitted_at)

    def close_position(self, symbol: str, qty: Optional[Decimal] = None) -> BrokerOrder:
        pos = self._positions[symbol]
        raise NotImplementedError("closes go through the OrderCoordinator as intents")

    def list_fills(self, client_order_id: str) -> Sequence[Fill]:
        return list(self._fills.get(client_order_id, []))

    def health_check(self) -> bool:
        return True
