"""The broker adapter contract every venue must satisfy.

The critical rule lives here: `find_order_by_client_id` returns exactly one of
FOUND / CONFIRMED_NOT_FOUND / UNKNOWN. Every ambiguous condition collapses to
UNKNOWN, and UNKNOWN never authorises a resubmission.
"""
from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from typing import Optional, Protocol, Sequence

from packages.domain.entities import (
    AccountSnapshot,
    Bar,
    BrokerOrder,
    Fill,
    Instrument,
    OrderIntent,
    Position,
    Quote,
)
from packages.domain.enums import OrderLookupStatus


class BrokerError(Exception):
    """Base class. `is_ambiguous` decides whether the order state is UNKNOWN."""

    is_ambiguous = True


class BrokerTimeout(BrokerError):
    """Request timed out. We do NOT know whether the broker accepted it."""


class BrokerUnavailable(BrokerError):
    """5xx / connection reset. Ambiguous."""


class BrokerAuthError(BrokerError):
    """401 / 403. Ambiguous with respect to order state -- treat as UNKNOWN."""


class BrokerRateLimited(BrokerError):
    """429. Ambiguous."""


class BrokerMalformedResponse(BrokerError):
    """Unparseable payload. Ambiguous."""


class BrokerRejected(BrokerError):
    """Broker explicitly and durably rejected the order. NOT ambiguous."""

    is_ambiguous = False


@dataclass(frozen=True)
class OrderLookup:
    status: OrderLookupStatus
    order: Optional[BrokerOrder] = None

    def __post_init__(self) -> None:
        if self.status is OrderLookupStatus.FOUND and self.order is None:
            raise ValueError("FOUND lookup must carry an order")
        if self.status is not OrderLookupStatus.FOUND and self.order is not None:
            raise ValueError("only FOUND may carry an order")


class BrokerAdapter(Protocol):
    """Implemented by broker_alpaca, broker_oanda, broker_coinbase,
    broker_polymarket and the deterministic simulator."""

    name: str

    def get_account(self) -> AccountSnapshot: ...

    def list_instruments(self) -> Sequence[Instrument]: ...

    def is_market_open(self, symbol: str) -> bool: ...

    def get_quote(self, symbol: str) -> Quote: ...

    def get_bars(self, symbol: str, timeframe: str, limit: int) -> Sequence[Bar]: ...

    def list_positions(self) -> Sequence[Position]: ...

    def list_open_orders(self) -> Sequence[BrokerOrder]: ...

    def find_order_by_client_id(self, client_order_id: str) -> OrderLookup: ...

    def submit_order(self, intent: OrderIntent) -> BrokerOrder: ...

    def cancel_order(self, broker_order_id: str) -> None: ...

    def close_position(self, symbol: str, qty: Optional[Decimal] = None) -> BrokerOrder: ...

    def list_fills(self, client_order_id: str) -> Sequence[Fill]: ...

    def health_check(self) -> bool: ...
