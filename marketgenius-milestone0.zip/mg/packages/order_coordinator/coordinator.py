"""The OrderCoordinator: the ONLY component authorised to call submit_order.

Strategies produce Signals. The opportunity engine ranks them. The risk engine
approves or rejects them. Nothing else touches the broker's write endpoints.

The submission sequence, and why each step exists:

  0. reconciliation probe (lookup by client_order_id)
        so a retry of an intent that already reached the venue cannot double
  1. risk evaluation on freshly fetched state
  2. reserve (durable write, state=RESERVED)
        so a crash after this point is always discoverable on restart
  3. state=SUBMITTING (durable write)
        marks the uncertainty window explicitly
  4. submit
  5. finalize (durable write, state=SUBMITTED)
        if THIS write fails the broker order exists and we do not have it
        recorded -- that is RECOVERY_REQUIRED, never a silent retry

Error handling rule, stated once and applied everywhere: an ambiguous broker
error leaves the order state UNKNOWN. UNKNOWN never resubmits. It escalates to
RECOVERY_REQUIRED and raises an incident for the recovery worker.
"""
from __future__ import annotations

import uuid
from dataclasses import dataclass
from typing import Optional

from packages.brokers.contract import (
    BrokerAdapter,
    BrokerError,
    BrokerRejected,
)
from packages.domain.entities import (
    Incident,
    OrderIntent,
    OrderReservation,
    RiskDecision,
    Signal,
    utc_now,
)
from packages.domain.enums import (
    Environment,
    OrderLookupStatus,
    ReservationState,
)
from packages.persistence.repository import InMemoryRepository, WriteFailure
from packages.risk_engine.engine import RiskContext, RiskEngine


class CoordinatorError(Exception):
    pass


class EnvironmentMismatch(CoordinatorError):
    """Refuses to route a PAPER intent to a LIVE adapter or vice versa."""


@dataclass(frozen=True)
class SubmissionResult:
    accepted: bool
    reservation: OrderReservation
    reason: Optional[str] = None
    risk_decision: Optional[RiskDecision] = None

    @property
    def state(self) -> ReservationState:
        return self.reservation.state


class OrderCoordinator:
    def __init__(
        self,
        broker: BrokerAdapter,
        repository: InMemoryRepository,
        risk_engine: RiskEngine,
        environment: Environment,
    ):
        self.broker = broker
        self.repo = repository
        self.risk = risk_engine
        self.environment = environment

    # ------------------------------------------------------------------

    def place(
        self,
        intent: OrderIntent,
        ctx: RiskContext,
        signal: Optional[Signal] = None,
    ) -> SubmissionResult:
        self._assert_environment(intent)

        # An intent already known to us is never re-run blindly.
        existing = self.repo.get_reservation(intent.client_order_id, self.environment)
        if existing is not None:
            return self._handle_existing(existing)

        reservation = OrderReservation(
            intent=intent,
            state=ReservationState.CREATED,
            created_at=utc_now(),
            updated_at=utc_now(),
        )

        # 0. Reconciliation probe BEFORE the risk gate.
        #
        # Adopting an order the venue already holds is bookkeeping, not a
        # trading decision. If risk ran first, an intent that had already
        # reached the broker could be locally marked REJECTED while the real
        # order sat open at the venue -- local state contradicting broker
        # truth, which is the failure mode that sank the previous system.
        # Risk still gates every NEW submission below.
        preflight = self._lookup(reservation)
        if preflight is OrderLookupStatus.FOUND:
            self.repo.save_reservation(reservation)
            return self._adopt_existing_broker_order(reservation, None)
        if preflight is OrderLookupStatus.UNKNOWN:
            self._escalate(reservation, "PRE_SUBMIT_LOOKUP_UNKNOWN")
            return SubmissionResult(False, reservation, "PRE_SUBMIT_LOOKUP_UNKNOWN")

        decision = self.risk.evaluate(intent, ctx, signal)

        if not decision.approved:
            reservation.transition(ReservationState.REJECTED,
                                   last_error=decision.primary_reason)
            self.repo.save_reservation(reservation)
            return SubmissionResult(False, reservation, decision.primary_reason, decision)

        # 1. Durable reservation BEFORE the submission attempt, so a crash
        #    from here on is always discoverable by the recovery worker.
        reservation.transition(ReservationState.RESERVED)
        self.repo.save_reservation(reservation)

        # 2. Enter the uncertainty window explicitly and durably.
        reservation.transition(ReservationState.SUBMITTING, attempts=reservation.attempts + 1)
        self.repo.save_reservation(reservation)

        # 3. Submit.
        try:
            order = self.broker.submit_order(intent)
        except BrokerRejected as exc:
            # Durable, unambiguous refusal: safe to close out locally.
            reservation.transition(ReservationState.REJECTED, last_error=str(exc))
            self.repo.save_reservation(reservation)
            return SubmissionResult(False, reservation, f"BROKER_REJECTED:{exc}", decision)
        except BrokerError as exc:
            # Ambiguous. The venue may or may not hold this order.
            self._escalate(reservation, f"SUBMIT_UNKNOWN:{type(exc).__name__}")
            return SubmissionResult(False, reservation,
                                    f"SUBMIT_UNKNOWN:{type(exc).__name__}", decision)

        # 4. Finalize. If this write fails the order EXISTS at the broker.
        try:
            reservation.transition(ReservationState.SUBMITTED,
                                   broker_order_id=order.broker_order_id)
            self.repo.save_reservation(reservation)
        except WriteFailure as exc:
            reservation.state = ReservationState.RECOVERY_REQUIRED
            reservation.last_error = f"FINALIZE_WRITE_FAILED:{exc}"
            self._force_persist(reservation)
            self._incident(reservation, "FINALIZE_WRITE_FAILED", str(exc))
            return SubmissionResult(False, reservation, "RECOVERY_REQUIRED", decision)

        self._sync_fills(reservation)
        return SubmissionResult(True, reservation, None, decision)

    # ------------------------------------------------------------------

    def _assert_environment(self, intent: OrderIntent) -> None:
        if intent.environment is not self.environment:
            raise EnvironmentMismatch(
                f"intent env {intent.environment.value} != coordinator env "
                f"{self.environment.value}")
        if getattr(self.broker, "environment", self.environment) is not self.environment:
            raise EnvironmentMismatch("broker adapter environment does not match coordinator")

    def _handle_existing(self, reservation: OrderReservation) -> SubmissionResult:
        """An intent we have seen before. Never resubmit from an uncertain
        state -- that is precisely how duplicate orders are born."""
        if reservation.state in (ReservationState.SUBMITTED, ReservationState.FINALIZED):
            return SubmissionResult(True, reservation, "ALREADY_SUBMITTED")
        return SubmissionResult(False, reservation, f"ALREADY_KNOWN:{reservation.state.value}")

    def _lookup(self, reservation: OrderReservation) -> OrderLookupStatus:
        try:
            return self.broker.find_order_by_client_id(reservation.client_order_id).status
        except BrokerError:
            # Every ambiguous failure collapses to UNKNOWN. Never optimistic.
            return OrderLookupStatus.UNKNOWN

    def _adopt_existing_broker_order(
        self, reservation: OrderReservation, decision: Optional[RiskDecision]
    ) -> SubmissionResult:
        lookup = self.broker.find_order_by_client_id(reservation.client_order_id)
        if lookup.status is not OrderLookupStatus.FOUND:
            self._escalate(reservation, "ADOPT_LOOKUP_CHANGED")
            return SubmissionResult(False, reservation, "ADOPT_LOOKUP_CHANGED", decision)
        reservation.transition(ReservationState.SUBMITTED,
                               broker_order_id=lookup.order.broker_order_id)
        self._force_persist(reservation)
        self._sync_fills(reservation)
        return SubmissionResult(True, reservation, "ADOPTED_EXISTING_BROKER_ORDER", decision)

    def _escalate(self, reservation: OrderReservation, reason: str) -> None:
        reservation.state = ReservationState.RECOVERY_REQUIRED
        reservation.last_error = reason
        reservation.updated_at = utc_now()
        self._force_persist(reservation)
        self._incident(reservation, reason, reservation.last_error or "")

    def _force_persist(self, reservation: OrderReservation) -> None:
        """Recovery bookkeeping must survive even a failing store; if the
        durable write cannot be made we still keep the in-process record so the
        restart worker can rebuild from broker truth."""
        try:
            self.repo.save_reservation(reservation)
        except WriteFailure:
            self.repo._reservations[reservation.environment][
                reservation.client_order_id] = reservation

    def _incident(self, reservation: OrderReservation, kind: str, detail: str) -> None:
        incident = Incident(
            id=str(uuid.uuid4()),
            environment=reservation.environment,
            kind=kind,
            detail=detail,
            created_at=utc_now(),
            client_order_id=reservation.client_order_id,
        )
        reservation.incident_id = incident.id
        self.repo.save_incident(incident)

    def _sync_fills(self, reservation: OrderReservation) -> None:
        try:
            for fill in self.broker.list_fills(reservation.client_order_id):
                self.repo.save_fill(fill)
        except BrokerError:
            # Fill sync is retried by the reconciliation worker; never fatal.
            pass
