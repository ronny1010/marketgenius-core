"""Restart / uncertainty recovery worker.

Runs on boot and on a schedule. For every reservation stuck in CREATED,
RESERVED, SUBMITTING or RECOVERY_REQUIRED it asks the broker one question:
does an order with this client_order_id exist?

  FOUND              -> adopt broker truth, mark SUBMITTED, sync fills
  CONFIRMED_NOT_FOUND-> the venue never took it; mark ABANDONED. A fresh
                        decision may later produce a NEW intent with a NEW id.
                        This worker never resubmits anything itself.
  UNKNOWN            -> leave untouched, count the attempt, try again later.
                        Blocking forever is correct; a duplicate live order is
                        worse than a stalled one.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence

from packages.brokers.contract import BrokerAdapter, BrokerError
from packages.domain.entities import OrderReservation, utc_now
from packages.domain.enums import Environment, OrderLookupStatus, ReservationState
from packages.persistence.repository import InMemoryRepository

STALE_STATES: Sequence[ReservationState] = (
    ReservationState.CREATED,
    ReservationState.RESERVED,
    ReservationState.SUBMITTING,
    ReservationState.RECOVERY_REQUIRED,
)


@dataclass(frozen=True)
class RecoveryReport:
    adopted: int = 0
    abandoned: int = 0
    still_unknown: int = 0

    @property
    def unresolved(self) -> int:
        return self.still_unknown


class RecoveryWorker:
    def __init__(
        self,
        broker: BrokerAdapter,
        repository: InMemoryRepository,
        environment: Environment,
    ):
        self.broker = broker
        self.repo = repository
        self.environment = environment

    def run(self) -> RecoveryReport:
        adopted = abandoned = unknown = 0

        for reservation in list(self.repo.list_reservations(self.environment, STALE_STATES)):
            status, order = self._lookup(reservation)

            if status is OrderLookupStatus.FOUND:
                reservation.transition(ReservationState.SUBMITTED,
                                       broker_order_id=order.broker_order_id,
                                       last_error=None)
                self._persist(reservation)
                self._sync_fills(reservation)
                adopted += 1

            elif status is OrderLookupStatus.CONFIRMED_NOT_FOUND:
                reservation.transition(ReservationState.ABANDONED,
                                       last_error="CONFIRMED_NOT_FOUND_AT_BROKER")
                self._persist(reservation)
                abandoned += 1

            else:  # UNKNOWN -- deliberately do nothing
                reservation.attempts += 1
                reservation.updated_at = utc_now()
                reservation.last_error = "RECOVERY_LOOKUP_UNKNOWN"
                if reservation.state is not ReservationState.RECOVERY_REQUIRED:
                    reservation.state = ReservationState.RECOVERY_REQUIRED
                self._persist(reservation)
                unknown += 1

        return RecoveryReport(adopted=adopted, abandoned=abandoned, still_unknown=unknown)

    def _lookup(self, reservation: OrderReservation):
        try:
            result = self.broker.find_order_by_client_id(reservation.client_order_id)
            return result.status, result.order
        except BrokerError:
            return OrderLookupStatus.UNKNOWN, None

    def _persist(self, reservation: OrderReservation) -> None:
        try:
            self.repo.save_reservation(reservation)
        except Exception:
            self.repo._reservations[reservation.environment][
                reservation.client_order_id] = reservation

    def _sync_fills(self, reservation: OrderReservation) -> None:
        try:
            for fill in self.broker.list_fills(reservation.client_order_id):
                self.repo.save_fill(fill)
        except BrokerError:
            pass
