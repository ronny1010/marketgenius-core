"""Bar hygiene. Strategies consume only what passes through here.

Rules enforced:
  - forming (incomplete) bars are dropped, never used for signals
  - duplicates by closed_at are removed, last write wins
  - bars are returned in ascending time order
  - gaps are detected and reported, never filled with manufactured data
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Sequence

from packages.domain.entities import Bar

TIMEFRAME_DELTA = {
    "15m": timedelta(minutes=15),
    "1h": timedelta(hours=1),
    "1d": timedelta(days=1),
}


class FormingBarError(Exception):
    """Raised when an incomplete bar reaches a consumer that forbids it."""


@dataclass(frozen=True)
class BarSeries:
    symbol: str
    timeframe: str
    bars: tuple[Bar, ...]
    gaps: tuple[datetime, ...]

    def __len__(self) -> int:
        return len(self.bars)

    @property
    def closes(self) -> tuple:
        return tuple(b.close for b in self.bars)

    @property
    def last(self) -> Bar:
        return self.bars[-1]


def prepare(symbol: str, timeframe: str, raw: Sequence[Bar]) -> BarSeries:
    complete = [b for b in raw if b.is_complete]

    deduped: dict = {}
    for bar in complete:
        deduped[bar.closed_at] = bar
    ordered = tuple(sorted(deduped.values(), key=lambda b: b.closed_at))

    step = TIMEFRAME_DELTA.get(timeframe)
    gaps: list[datetime] = []
    if step and len(ordered) > 1:
        for prev, nxt in zip(ordered, ordered[1:]):
            expected = prev.closed_at + step
            while expected < nxt.closed_at:
                gaps.append(expected)   # reported, never synthesised
                expected += step

    return BarSeries(symbol=symbol, timeframe=timeframe, bars=ordered, gaps=tuple(gaps))


def assert_all_complete(bars: Sequence[Bar]) -> None:
    if any(not b.is_complete for b in bars):
        raise FormingBarError("forming bar reached a signal-producing consumer")
